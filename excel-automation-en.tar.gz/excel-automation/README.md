# 📊 Excel Automation Tool

Потужний інструмент для автоматизації роботи з Excel файлами: збір даних з декількох файлів, обробка, аналіз та генерація професійних звітів.

## ✨ Можливості

### 📥 Збір даних
- Автоматичне завантаження всіх Excel файлів з папки
- Підтримка різних форматів (.xlsx, .xlsm, .xls)
- Обробка помилок при читанні файлів

### 🔄 Обробка даних
- **Об'єднання** - merge або concat декількох файлів
- **Фільтрація** - складні умови фільтрації (мін/макс, рівність, текстовий пошук)
- **Групування** - агрегація даних за категоріями
- **Розрахунки** - статистика (сума, середнє, медіана, min/max, std)

### 📊 Генерація звітів
- Автоматичне створення Excel звітів
- Професійне форматування (кольори, шрифти, рамки)
- Декілька листів в одному файлі
- Автоматичне підлаштування ширини колонок

### 🎨 Стилізація
- Кольорові заголовки
- Вирівнювання тексту
- Рамки для таблиць
- Форматування числових даних

## 🛠 Технології

- **Python 3.8+**
- **pandas** - обробка та аналіз даних
- **openpyxl** - робота з Excel, формули та форматування
- **numpy** - числові розрахунки

## 📦 Встановлення

### 1. Клонуйте репозиторій

```bash
git clone https://github.com/yourusername/excel-automation.git
cd excel-automation
```

### 2. Створіть віртуальне середовище

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### 3. Встановіть залежності

```bash
pip install -r requirements.txt
```

## 🚀 Швидкий старт

### Створення тестових даних

```bash
python excel_processor.py --create-sample
```

Це створить папку `input_data` з двома прикладами файлів.

### Запуск базового аналізу

```bash
python excel_processor.py
```

Скрипт:
1. Завантажить всі файли з `input_data/`
2. Об'єднає дані
3. Розрахує статистику
4. Застосує фільтри
5. Створить звіт у папці `output/`

### Вказати свої папки

```bash
python excel_processor.py --input my_data --output my_reports
```

## 💻 Використання як бібліотеки

### Базовий приклад

```python
from excel_processor import ExcelProcessor

# Ініціалізація
processor = ExcelProcessor(input_folder="input_data", output_folder="output")

# Завантаження всіх файлів
processor.load_all_files()

# Об'єднання даних
merged_data = processor.merge_data()

# Розрахунок статистики
stats = processor.calculate_statistics(merged_data)

# Створення звіту
processor.create_summary_report(merged_data, stats)
```

### Фільтрація даних

```python
# Прості фільтри
filtered = processor.filter_data(df, {
    'Ціна': 100,  # Точна відповідність
    'Категорія': 'Електроніка'
})

# Складні фільтри
filtered = processor.filter_data(df, {
    'Ціна': {'min': 100, 'max': 500},  # Діапазон
    'Кількість': {'min': 10},           # Мінімум
    'Продукт': {'contains': 'Товар'}    # Містить текст
})
```

### Групування та агрегація

```python
# Групуємо по категоріях
grouped = processor.group_and_aggregate(
    df,
    group_by='Категорія',
    agg_funcs={
        'Ціна': 'mean',      # Середня ціна
        'Кількість': 'sum'   # Загальна кількість
    }
)
```

### Створення звіту з декількома листами

```python
# Підготовка даних для різних листів
all_data = merged_data
statistics = processor.calculate_statistics(merged_data)
top_10 = merged_data.nlargest(10, 'Ціна')

# Створення звіту
processor.create_styled_report(
    "monthly_report.xlsx",
    **{
        "Всі дані": all_data,
        "Статистика": statistics,
        "Топ 10": top_10
    }
)
```

## 📚 Приклади

Дивіться `examples.py` для більше прикладів:

```bash
python examples.py
```

Цей файл демонструє:
- Базове об'єднання файлів
- Розрахунок статистики
- Різні типи фільтрів
- Групування даних
- Створення комплексних звітів

## 📁 Структура проекту

```
excel-automation/
│
├── excel_processor.py      # Основний модуль
├── examples.py              # Приклади використання
├── requirements.txt         # Залежності
├── README.md               # Документація
│
├── input_data/             # Вхідні Excel файли (створюється автоматично)
│   ├── sales_jan.xlsx
│   └── sales_feb.xlsx
│
└── output/                 # Згенеровані звіти (створюється автоматично)
    └── report_*.xlsx
```

## 🎯 Use Cases

### 1. Консолідація продажів

Об'єднайте дані продажів з різних філій:

```python
processor = ExcelProcessor(input_folder="sales_by_branch")
merged = processor.merge_data()
stats = processor.calculate_statistics(merged)
processor.create_summary_report(merged, stats)
```

### 2. Аналіз фінансових даних

```python
# Завантажити квартальні звіти
processor.load_all_files()

# Розрахувати підсумки
quarterly_data = processor.merge_data()

# Групувати по категоріях витрат
expenses = processor.group_and_aggregate(
    quarterly_data,
    group_by='Категорія',
    agg_funcs={'Сума': 'sum'}
)
```

### 3. Інвентаризація

```python
# Знайти товари з низьким запасом
low_stock = processor.filter_data(inventory, {
    'Кількість': {'max': 10}
})

# Створити звіт
processor.create_styled_report(
    "low_stock_alert.xlsx",
    **{"Товари з низьким запасом": low_stock}
)
```

## 🔧 Налаштування

### Формати дат

```python
df = pd.read_excel('file.xlsx', parse_dates=['Дата'])
```

### Типи даних

```python
df = pd.read_excel('file.xlsx', dtype={'ID': str, 'Код': str})
```

### Вибір конкретних колонок

```python
df = pd.read_excel('file.xlsx', usecols=['Назва', 'Ціна', 'Кількість'])
```

## 📊 Класс ExcelProcessor API

### Методи

#### `__init__(input_folder, output_folder)`
Ініціалізує процесор

#### `collect_files(pattern="*.xlsx")`
Збирає файли за патерном

#### `load_all_files()`
Завантажує всі файли в пам'ять

#### `merge_data(how="outer", on=None)`
Об'єднує дані
- `how`: "outer", "inner", "left", "right"
- `on`: колонка для об'єднання

#### `calculate_statistics(df)`
Розраховує статистику

#### `filter_data(df, filters)`
Фільтрує дані за умовами

#### `group_and_aggregate(df, group_by, agg_funcs)`
Групує та агрегує

#### `create_styled_report(output_file, **sheets)`
Створює стильний звіт

## 🎨 Стилі звітів

Автоматично застосовуються:
- **Заголовки**: синій фон, білий текст, жирний шрифт
- **Вирівнювання**: центр для заголовків, ліворуч для даних
- **Рамки**: тонкі лінії навколо всіх клітинок
- **Ширина колонок**: автоматично підлаштовується під контент

Можна кастомізувати через openpyxl:

```python
from openpyxl.styles import Font, PatternFill

# Свій стиль
cell.font = Font(bold=True, color="FF0000")
cell.fill = PatternFill(start_color="FFFF00", fill_type="solid")
```

## 🚨 Обробка помилок

Скрипт обробляє:
- Відсутність файлів або папок
- Пошкоджені Excel файли
- Невідповідність структури даних
- Помилки типів даних

Всі помилки логуються з детальною інформацією.

## 📈 Продуктивність

### Великі файли

Для файлів >100MB використовуйте chunking:

```python
chunks = pd.read_excel('large_file.xlsx', chunksize=10000)
for chunk in chunks:
    # Обробка по частинам
    process_chunk(chunk)
```

### Оптимізація пам'яті

```python
# Читати тільки потрібні колонки
df = pd.read_excel('file.xlsx', usecols=['A', 'B', 'C'])

# Вказувати типи даних
df = pd.read_excel('file.xlsx', dtype={'ID': 'int32'})
```

## 🧪 Тестування

```bash
# Створити тестові дані
python excel_processor.py --create-sample

# Запустити всі приклади
python examples.py

# Перевірити вихідні файли
ls output/
```

## 🤝 Внесок

1. Fork репозиторій
2. Створіть гілку: `git checkout -b feature/AmazingFeature`
3. Commit зміни: `git commit -m 'Add AmazingFeature'`
4. Push в гілку: `git push origin feature/AmazingFeature`
5. Відкрийте Pull Request

## 📄 Ліцензія

MIT License - дивіться [LICENSE](LICENSE) для деталей

## 👤 Автор

Ваше ім'я - [@your_username](https://github.com/your_username)

## 🙏 Подяки

- [pandas](https://pandas.pydata.org/) - потужна бібліотека для аналізу даних
- [openpyxl](https://openpyxl.readthedocs.io/) - робота з Excel файлами
- [numpy](https://numpy.org/) - числові розрахунки

## 📞 Підтримка

Якщо у вас виникли питання або проблеми:
- Створіть [Issue](https://github.com/yourusername/excel-automation/issues)
- Напишіть на email: your@email.com

---

⭐️ Якщо проект виявився корисним, поставте зірочку!
