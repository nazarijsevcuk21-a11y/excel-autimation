"""
Excel Automation Script
Автоматизує збір та обробку даних з декількох Excel файлів
"""

import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
from pathlib import Path
from datetime import datetime
import logging
from typing import List, Dict, Optional
import argparse

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ExcelProcessor:
    """Клас для обробки Excel файлів"""
    
    def __init__(self, input_folder: str = "input_data", output_folder: str = "output"):
        self.input_folder = Path(input_folder)
        self.output_folder = Path(output_folder)
        self.output_folder.mkdir(exist_ok=True)
        self.data_frames = {}
        
    def collect_files(self, pattern: str = "*.xlsx") -> List[Path]:
        """Збирає всі Excel файли з папки"""
        if not self.input_folder.exists():
            logger.error(f"Папка {self.input_folder} не існує")
            return []
        
        files = list(self.input_folder.glob(pattern))
        logger.info(f"Знайдено {len(files)} файлів")
        return files
    
    def read_excel_file(self, file_path: Path) -> Optional[pd.DataFrame]:
        """Читає один Excel файл"""
        try:
            df = pd.read_excel(file_path)
            logger.info(f"Прочитано {file_path.name}: {len(df)} рядків")
            return df
        except Exception as e:
            logger.error(f"Помилка читання {file_path.name}: {e}")
            return None
    
    def load_all_files(self) -> Dict[str, pd.DataFrame]:
        """Завантажує всі файли в пам'ять"""
        files = self.collect_files()
        
        for file_path in files:
            df = self.read_excel_file(file_path)
            if df is not None:
                self.data_frames[file_path.stem] = df
        
        logger.info(f"Завантажено {len(self.data_frames)} файлів")
        return self.data_frames
    
    def merge_data(self, how: str = "outer", on: Optional[str] = None) -> pd.DataFrame:
        """Об'єднує всі дані в один DataFrame"""
        if not self.data_frames:
            logger.warning("Немає даних для об'єднання")
            return pd.DataFrame()
        
        dfs = list(self.data_frames.values())
        
        if len(dfs) == 1:
            return dfs[0]
        
        if on:
            result = dfs[0]
            for df in dfs[1:]:
                result = pd.merge(result, df, how=how, on=on)
        else:
            result = pd.concat(dfs, ignore_index=True)
        
        logger.info(f"Об'єднано дані: {len(result)} рядків")
        return result
    
    def calculate_statistics(self, df: pd.DataFrame) -> pd.DataFrame:
        """Розраховує статистику по числовим колонкам"""
        numeric_cols = df.select_dtypes(include=['number']).columns
        
        stats = pd.DataFrame({
            'Показник': ['Кількість', 'Сума', 'Середнє', 'Медіана', 'Мінімум', 'Максимум', 'Стд. відхилення']
        })
        
        for col in numeric_cols:
            stats[col] = [
                len(df[col]),
                df[col].sum(),
                df[col].mean(),
                df[col].median(),
                df[col].min(),
                df[col].max(),
                df[col].std()
            ]
        
        return stats
    
    def filter_data(self, df: pd.DataFrame, filters: Dict[str, any]) -> pd.DataFrame:
        """Фільтрує дані за заданими критеріями"""
        filtered = df.copy()
        
        for column, condition in filters.items():
            if column not in df.columns:
                logger.warning(f"Колонка {column} не знайдена")
                continue
            
            if isinstance(condition, dict):
                if 'min' in condition:
                    filtered = filtered[filtered[column] >= condition['min']]
                if 'max' in condition:
                    filtered = filtered[filtered[column] <= condition['max']]
                if 'equals' in condition:
                    filtered = filtered[filtered[column] == condition['equals']]
                if 'contains' in condition:
                    filtered = filtered[filtered[column].astype(str).str.contains(condition['contains'], na=False)]
            else:
                filtered = filtered[filtered[column] == condition]
        
        logger.info(f"Після фільтрації: {len(filtered)} рядків")
        return filtered
    
    def group_and_aggregate(self, df: pd.DataFrame, group_by: str, agg_funcs: Dict[str, str]) -> pd.DataFrame:
        """Групує дані та агрегує"""
        if group_by not in df.columns:
            logger.error(f"Колонка для групування {group_by} не знайдена")
            return pd.DataFrame()
        
        result = df.groupby(group_by).agg(agg_funcs).reset_index()
        logger.info(f"Згруповано: {len(result)} груп")
        return result
    
    def create_styled_report(self, output_file: str, **sheets):
        """Створює стильний звіт з декількома листами"""
        output_path = self.output_folder / output_file
        
        wb = openpyxl.Workbook()
        wb.remove(wb.active)
        
        for sheet_name, df in sheets.items():
            ws = wb.create_sheet(sheet_name)
            
            for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=True), 1):
                for c_idx, value in enumerate(row, 1):
                    cell = ws.cell(row=r_idx, column=c_idx, value=value)
                    
                    if r_idx == 1:
                        cell.font = Font(bold=True, color="FFFFFF")
                        cell.fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
                        cell.alignment = Alignment(horizontal="center", vertical="center")
                    else:
                        cell.alignment = Alignment(horizontal="left", vertical="center")
                    
                    thin_border = Border(
                        left=Side(style='thin'),
                        right=Side(style='thin'),
                        top=Side(style='thin'),
                        bottom=Side(style='thin')
                    )
                    cell.border = thin_border
            
            for column in ws.columns:
                max_length = 0
                column_letter = column[0].column_letter
                for cell in column:
                    try:
                        if cell.value:
                            max_length = max(max_length, len(str(cell.value)))
                    except:
                        pass
                adjusted_width = min(max_length + 2, 50)
                ws.column_dimensions[column_letter].width = adjusted_width
        
        wb.save(output_path)
        logger.info(f"Звіт збережено: {output_path}")
        return output_path
    
    def create_summary_report(self, data: pd.DataFrame, statistics: pd.DataFrame, 
                            filtered_data: pd.DataFrame = None) -> Path:
        """Створює підсумковий звіт"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"report_{timestamp}.xlsx"
        
        sheets = {
            "Всі дані": data.head(1000),
            "Статистика": statistics
        }
        
        if filtered_data is not None and not filtered_data.empty:
            sheets["Відфільтровані дані"] = filtered_data.head(1000)
        
        return self.create_styled_report(output_file, **sheets)


def example_sales_analysis():
    """Приклад аналізу продажів"""
    processor = ExcelProcessor()
    
    logger.info("=== Приклад: Аналіз продажів ===")
    
    processor.load_all_files()
    
    if not processor.data_frames:
        logger.warning("Немає даних для обробки. Створюю приклад...")
        create_sample_data()
        processor.load_all_files()
    
    merged_data = processor.merge_data()
    
    if merged_data.empty:
        logger.error("Немає даних після об'єднання")
        return
    
    stats = processor.calculate_statistics(merged_data)
    
    numeric_cols = merged_data.select_dtypes(include=['number']).columns
    if len(numeric_cols) > 0:
        first_numeric = numeric_cols[0]
        mean_value = merged_data[first_numeric].mean()
        filtered = processor.filter_data(
            merged_data, 
            {first_numeric: {'min': mean_value}}
        )
    else:
        filtered = merged_data
    
    report_path = processor.create_summary_report(merged_data, stats, filtered)
    logger.info(f"✅ Звіт створено: {report_path}")


def create_sample_data():
    """Створює приклад вхідних даних"""
    input_folder = Path("input_data")
    input_folder.mkdir(exist_ok=True)
    
    import numpy as np
    np.random.seed(42)
    
    df1 = pd.DataFrame({
        'Продукт': [f'Товар {i}' for i in range(1, 51)],
        'Категорія': np.random.choice(['Електроніка', 'Одяг', 'Їжа', 'Книги'], 50),
        'Ціна': np.random.uniform(50, 500, 50).round(2),
        'Кількість': np.random.randint(1, 100, 50)
    })
    
    df2 = pd.DataFrame({
        'Продукт': [f'Товар {i}' for i in range(51, 101)],
        'Категорія': np.random.choice(['Електроніка', 'Одяг', 'Їжа', 'Книги'], 50),
        'Ціна': np.random.uniform(50, 500, 50).round(2),
        'Кількість': np.random.randint(1, 100, 50)
    })
    
    df1.to_excel(input_folder / "sales_jan.xlsx", index=False)
    df2.to_excel(input_folder / "sales_feb.xlsx", index=False)
    
    logger.info("✅ Створено приклад даних в папці input_data/")


def main():
    """Головна функція"""
    parser = argparse.ArgumentParser(description='Excel Automation Tool')
    parser.add_argument('--input', default='input_data', help='Папка з вхідними файлами')
    parser.add_argument('--output', default='output', help='Папка для збереження звітів')
    parser.add_argument('--create-sample', action='store_true', help='Створити приклад даних')
    
    args = parser.parse_args()
    
    if args.create_sample:
        create_sample_data()
        return
    
    processor = ExcelProcessor(args.input, args.output)
    example_sales_analysis()


if __name__ == "__main__":
    main()
