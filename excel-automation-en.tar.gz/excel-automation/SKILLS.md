# 🎯 Технічні навички - Excel Automation

## Використані технології та демонстрація навичок

### 📚 Core Technologies

#### Python 3.8+
- Об'єктно-орієнтоване програмування (OOP)
- Type hints для кращої читабельності
- Робота з pathlib для файлових операцій
- Argparse для CLI інтерфейсу
- Logging для відстеження виконання

#### Pandas
- Читання та запис Excel файлів
- Data manipulation та аналіз
- Групування та агрегація даних
- Фільтрація з складними умовами
- Об'єднання DataFrames (merge, concat)
- Статистичні розрахунки

#### OpenPyXL
- Створення та редагування Excel файлів
- Стилізація (шрифти, кольори, рамки)
- Робота з формулами Excel
- Багатолистові документи
- Автоматичне форматування

#### NumPy
- Генерація випадкових даних
- Числові розрахунки
- Робота з масивами

---

## 💻 Демонстрація навичок у коді

### 1. Об'єктно-орієнтоване програмування

```python
class ExcelProcessor:
    """Інкапсуляція всієї логіки обробки"""
    
    def __init__(self, input_folder: str, output_folder: str):
        self.input_folder = Path(input_folder)
        self.output_folder = Path(output_folder)
        self.data_frames = {}
    
    def load_all_files(self) -> Dict[str, pd.DataFrame]:
        """Завантаження з обробкою помилок"""
        # Реалізація...
```

**Демонструє:**
- Class design
- Encapsulation
- Type hints
- Методи з чітким призначенням

### 2. Робота з Pandas

```python
def calculate_statistics(self, df: pd.DataFrame) -> pd.DataFrame:
    """Використання pandas для статистичних розрахунків"""
    numeric_cols = df.select_dtypes(include=['number']).columns
    
    stats = pd.DataFrame({
        'Показник': ['Кількість', 'Сума', 'Середнє', 'Медіана', 
                     'Мінімум', 'Максимум', 'Стд. відхилення']
    })
    
    for col in numeric_cols:
        stats[col] = [
            len(df[col]),
            df[col].sum(),
            df[col].mean(),
            df[col].median(),
            df[col].min(),
            df[col].max(),
            df[col].std()
        ]
    
    return stats
```

**Демонструє:**
- Вибірка типів даних
- Динамічне створення DataFrame
- Статистичні функції pandas
- Обробка числових даних

### 3. Складна фільтрація

```python
def filter_data(self, df: pd.DataFrame, filters: Dict[str, any]) -> pd.DataFrame:
    """Гнучка система фільтрації"""
    filtered = df.copy()
    
    for column, condition in filters.items():
        if isinstance(condition, dict):
            # Складні умови
            if 'min' in condition:
                filtered = filtered[filtered[column] >= condition['min']]
            if 'max' in condition:
                filtered = filtered[filtered[column] <= condition['max']]
            if 'contains' in condition:
                filtered = filtered[
                    filtered[column].astype(str).str.contains(
                        condition['contains'], na=False
                    )
                ]
        else:
            # Проста рівність
            filtered = filtered[filtered[column] == condition]
    
    return filtered
```

**Демонструє:**
- Робота з dict та різними типами даних
- Boolean indexing у pandas
- String operations
- Edge cases handling (na=False)
- Chainable filtering

### 4. Стилізація Excel з OpenPyXL

```python
def create_styled_report(self, output_file: str, **sheets):
    """Професійне форматування Excel"""
    wb = openpyxl.Workbook()
    
    for sheet_name, df in sheets.items():
        ws = wb.create_sheet(sheet_name)
        
        for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=True), 1):
            for c_idx, value in enumerate(row, 1):
                cell = ws.cell(row=r_idx, column=c_idx, value=value)
                
                if r_idx == 1:
                    # Стиль заголовків
                    cell.font = Font(bold=True, color="FFFFFF")
                    cell.fill = PatternFill(
                        start_color="4472C4", 
                        end_color="4472C4", 
                        fill_type="solid"
                    )
                    cell.alignment = Alignment(
                        horizontal="center", 
                        vertical="center"
                    )
                
                # Рамки
                cell.border = Border(
                    left=Side(style='thin'),
                    right=Side(style='thin'),
                    top=Side(style='thin'),
                    bottom=Side(style='thin')
                )
        
        # Автоматична ширина колонок
        for column in ws.columns:
            max_length = max(len(str(cell.value)) for cell in column)
            ws.column_dimensions[column[0].column_letter].width = min(max_length + 2, 50)
    
    wb.save(output_path)
```

**Демонструє:**
- Робота з openpyxl API
- Стилізація Excel (Font, Fill, Alignment, Border)
- Динамічне форматування
- Оптимізація розмірів колонок
- Багатолистові документи

### 5. Обробка помилок та логування

```python
def read_excel_file(self, file_path: Path) -> Optional[pd.DataFrame]:
    """Надійне читання файлів"""
    try:
        df = pd.read_excel(file_path)
        logger.info(f"Прочитано {file_path.name}: {len(df)} рядків")
        return df
    except Exception as e:
        logger.error(f"Помилка читання {file_path.name}: {e}")
        return None
```

**Демонструє:**
- Try-except обробка
- Logging для debugging
- Optional type hints
- Graceful error handling

### 6. CLI інтерфейс з Argparse

```python
def main():
    parser = argparse.ArgumentParser(description='Excel Automation Tool')
    parser.add_argument('--input', default='input_data', 
                       help='Папка з вхідними файлами')
    parser.add_argument('--output', default='output', 
                       help='Папка для збереження звітів')
    parser.add_argument('--create-sample', action='store_true', 
                       help='Створити приклад даних')
    
    args = parser.parse_args()
```

**Демонструє:**
- CLI development
- Argparse usage
- User-friendly interface
- Default values

---

## 🏗 Архітектурні паттерни

### 1. Single Responsibility Principle

Кожен метод має одну відповідальність:
- `collect_files()` - тільки збір файлів
- `read_excel_file()` - тільки читання
- `calculate_statistics()` - тільки статистика
- `filter_data()` - тільки фільтрація

### 2. Dependency Injection

```python
def __init__(self, input_folder: str, output_folder: str):
    # Папки передаються ззовні, не hardcoded
    self.input_folder = Path(input_folder)
    self.output_folder = Path(output_folder)
```

### 3. Factory Pattern

```python
def create_styled_report(self, output_file: str, **sheets):
    """Створює різні типи звітів"""
    # Динамічне створення листів
    for sheet_name, df in sheets.items():
        ws = wb.create_sheet(sheet_name)
```

### 4. Strategy Pattern

```python
def merge_data(self, how: str = "outer", on: Optional[str] = None):
    """Різні стратегії об'єднання"""
    if on:
        result = pd.merge(result, df, how=how, on=on)
    else:
        result = pd.concat(dfs, ignore_index=True)
```

---

## 📊 Pandas Advanced Techniques

### DataFrame Operations

```python
# Вибір типів даних
numeric_cols = df.select_dtypes(include=['number']).columns

# Групування та агрегація
grouped = df.groupby('Категорія').agg({
    'Ціна': 'mean',
    'Кількість': 'sum'
})

# Сортування
top_10 = df.nlargest(10, 'Загальна вартість')

# Фільтрація
filtered = df[df['Ціна'] > 100]

# Робота з рядками
df[df['Продукт'].str.contains('Товар', na=False)]
```

### Data Transformation

```python
# Додавання нових колонок
df['Загальна вартість'] = df['Ціна'] * df['Кількість']

# Merge різних типів
pd.merge(df1, df2, how='outer', on='ID')
pd.concat([df1, df2], ignore_index=True)

# Reset index
df.reset_index(drop=True, inplace=True)
```

---

## 🎨 OpenPyXL Styling Guide

### Fonts
```python
Font(
    name='Arial',
    size=11,
    bold=True,
    italic=False,
    color='FF0000'  # RGB hex
)
```

### Fills
```python
PatternFill(
    start_color='FFFF00',
    end_color='FFFF00',
    fill_type='solid'
)
```

### Alignment
```python
Alignment(
    horizontal='center',  # left, center, right
    vertical='center',    # top, center, bottom
    wrap_text=True
)
```

### Borders
```python
Border(
    left=Side(style='thin'),
    right=Side(style='thin'),
    top=Side(style='thin'),
    bottom=Side(style='thin')
)
```

---

## 💡 Best Practices у проекті

### 1. Type Hints скрізь

```python
def filter_data(
    self, 
    df: pd.DataFrame, 
    filters: Dict[str, any]
) -> pd.DataFrame:
```

### 2. Docstrings для документації

```python
def calculate_statistics(self, df: pd.DataFrame) -> pd.DataFrame:
    """
    Розраховує статистику по числовим колонкам
    
    Args:
        df: DataFrame для аналізу
        
    Returns:
        DataFrame зі статистикою
    """
```

### 3. Логування замість print

```python
logger.info("Завантажено файлів: 5")
logger.warning("Колонка не знайдена")
logger.error("Помилка читання файлу")
```

### 4. Path замість str для файлів

```python
from pathlib import Path

self.input_folder = Path(input_folder)
files = self.input_folder.glob("*.xlsx")
```

### 5. Обробка помилок

```python
try:
    df = pd.read_excel(file_path)
except Exception as e:
    logger.error(f"Error: {e}")
    return None
```

---

## 📈 Продуктивність

### Memory Optimization

```python
# Читання тільки потрібних колонок
df = pd.read_excel('large.xlsx', usecols=['A', 'B', 'C'])

# Вказання типів даних
df = pd.read_excel('file.xlsx', dtype={'ID': 'int32'})

# Chunking для великих файлів
for chunk in pd.read_excel('huge.xlsx', chunksize=10000):
    process(chunk)
```

### Vectorization

```python
# Швидко ✅
df['Total'] = df['Price'] * df['Quantity']

# Повільно ❌
df['Total'] = df.apply(lambda row: row['Price'] * row['Quantity'], axis=1)
```

---

## 🔍 Testing Approaches

```python
# Unit tests (приклад)
def test_filter_data():
    processor = ExcelProcessor()
    df = pd.DataFrame({'Price': [100, 200, 300]})
    
    filtered = processor.filter_data(df, {'Price': {'min': 150}})
    assert len(filtered) == 2
    assert filtered['Price'].min() >= 150

# Integration tests
def test_full_pipeline():
    processor = ExcelProcessor()
    processor.load_all_files()
    merged = processor.merge_data()
    assert not merged.empty
```

---

## 💼 Для портфоліо / співбесіди

**Що демонструє цей проект:**

✅ **Технічні навички:**
- Python OOP
- Pandas data manipulation
- OpenPyXL styling
- File I/O operations
- Error handling

✅ **Розуміння best practices:**
- Clean code
- Type hints
- Logging
- Documentation
- CLI development

✅ **Практичні навички:**
- Реальний use case
- Production-ready код
- Extensible architecture
- User-friendly interface

✅ **Soft skills:**
- Документація
- Code organization
- Error messages
- User experience

---

## 📊 Метрики проекту

- **Lines of Code:** ~300 (основний модуль)
- **Functions:** 12 публічних методів
- **Classes:** 1 основний клас
- **Documentation:** 200+ рядків README
- **Examples:** 6 різних use cases
- **Dependencies:** 4 core libraries

---

## 🚀 Можливості розширення

1. **Database Integration** - збереження в PostgreSQL/MySQL
2. **API endpoints** - Flask/FastAPI обгортка
3. **Scheduling** - автоматичне виконання за розкладом
4. **Email Reports** - відправка звітів поштою
5. **Dashboard** - Web UI з Streamlit/Dash
6. **Charts** - візуалізація даних у Excel

Проект демонструє solid foundation для таких розширень!
