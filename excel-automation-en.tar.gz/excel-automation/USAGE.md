# 📘 Детальне використання - Excel Automation

## Реальні сценарії використання

### Сценарій 1: Консолідація продажів з філій

**Ситуація:** У вас є Excel файли з продажами з 5 філій за місяць. Потрібно об'єднати їх та створити загальний звіт.

**Файли:**
- `filial_kyiv.xlsx`
- `filial_lviv.xlsx`
- `filial_odesa.xlsx`
- `filial_kharkiv.xlsx`
- `filial_dnipro.xlsx`

**Код:**

```python
from excel_processor import ExcelProcessor

# Ініціалізація
processor = ExcelProcessor(
    input_folder="sales_data",
    output_folder="monthly_reports"
)

# Завантаження всіх філій
processor.load_all_files()

# Об'єднання даних
all_sales = processor.merge_data()

# Додаємо обчислювану колонку
all_sales['Виручка'] = all_sales['Ціна'] * all_sales['Кількість']

# Статистика
stats = processor.calculate_statistics(all_sales)

# Топ продукти
top_products = all_sales.nlargest(20, 'Виручка')

# Статистика по філіях
if 'Філія' in all_sales.columns:
    by_filial = processor.group_and_aggregate(
        all_sales,
        group_by='Філія',
        agg_funcs={
            'Виручка': 'sum',
            'Кількість': 'sum'
        }
    )
else:
    by_filial = pd.DataFrame()

# Створення звіту
processor.create_styled_report(
    "sales_report_november.xlsx",
    **{
        "Всі продажі": all_sales,
        "Топ 20 товарів": top_products,
        "По філіях": by_filial,
        "Статистика": stats
    }
)
```

---

### Сценарій 2: Аналіз запасів на складі

**Ситуація:** Потрібно знайти товари з низьким запасом та створити звіт для закупівлі.

**Код:**

```python
from excel_processor import ExcelProcessor
import pandas as pd

processor = ExcelProcessor(
    input_folder="inventory",
    output_folder="inventory_reports"
)

# Завантаження даних
processor.load_all_files()
inventory = processor.merge_data()

# Фільтр: товари з залишком < 10 одиниць
low_stock = processor.filter_data(inventory, {
    'Залишок': {'max': 10}
})

# Сортування по категоріях
low_stock_sorted = low_stock.sort_values(['Категорія', 'Назва'])

# Критичні товари (< 3 одиниць)
critical = processor.filter_data(inventory, {
    'Залишок': {'max': 3}
})

# Статистика по категоріях
category_stats = processor.group_and_aggregate(
    inventory,
    group_by='Категорія',
    agg_funcs={
        'Залишок': 'sum',
        'Ціна закупки': 'mean'
    }
)

# Створення звіту
processor.create_styled_report(
    "inventory_alert.xlsx",
    **{
        "Низький запас": low_stock_sorted,
        "КРИТИЧНІ": critical,
        "По категоріях": category_stats
    }
)

print(f"⚠️ Товарів з низьким запасом: {len(low_stock)}")
print(f"🚨 Критичних товарів: {len(critical)}")
```

---

### Сценарій 3: Аналіз фінансових витрат

**Ситуація:** Маєте квартальні звіти про витрати. Потрібно проаналізувати та знайти можливості економії.

**Код:**

```python
from excel_processor import ExcelProcessor
import pandas as pd

processor = ExcelProcessor(
    input_folder="expenses_Q1_2024",
    output_folder="financial_analysis"
)

# Завантаження
processor.load_all_files()
expenses = processor.merge_data()

# Конвертація дат якщо потрібно
if 'Дата' in expenses.columns:
    expenses['Дата'] = pd.to_datetime(expenses['Дата'])
    expenses['Місяць'] = expenses['Дата'].dt.month_name()

# Статистика по категоріях витрат
by_category = processor.group_and_aggregate(
    expenses,
    group_by='Категорія витрат',
    agg_funcs={
        'Сума': 'sum',
        'Кількість': 'count'
    }
)
by_category = by_category.sort_values('Сума', ascending=False)

# Великі витрати (> 10000)
large_expenses = processor.filter_data(expenses, {
    'Сума': {'min': 10000}
})

# По місяцях (якщо є колонка Місяць)
if 'Місяць' in expenses.columns:
    by_month = processor.group_and_aggregate(
        expenses,
        group_by='Місяць',
        agg_funcs={'Сума': 'sum'}
    )
else:
    by_month = pd.DataFrame()

# Повторювані витрати
if 'Постачальник' in expenses.columns:
    by_supplier = processor.group_and_aggregate(
        expenses,
        group_by='Постачальник',
        agg_funcs={
            'Сума': 'sum',
            'Кількість': 'count'
        }
    )
    by_supplier = by_supplier.sort_values('Сума', ascending=False)
else:
    by_supplier = pd.DataFrame()

# Звіт
processor.create_styled_report(
    "expense_analysis_Q1.xlsx",
    **{
        "Всі витрати": expenses,
        "По категоріях": by_category,
        "Великі витрати": large_expenses,
        "По місяцях": by_month,
        "По постачальниках": by_supplier
    }
)

# Підсумки в консоль
total = expenses['Сума'].sum()
avg = expenses['Сума'].mean()
print(f"💰 Загальні витрати Q1: ${total:,.2f}")
print(f"📊 Середня витрата: ${avg:,.2f}")
print(f"🔝 Топ категорія: {by_category.iloc[0].name}")
```

---

### Сценарій 4: Аналіз успішності студентів

**Ситуація:** Маєте оцінки студентів з різних предметів. Потрібно проаналізувати успішність.

**Код:**

```python
from excel_processor import ExcelProcessor
import pandas as pd

processor = ExcelProcessor(
    input_folder="grades",
    output_folder="academic_reports"
)

# Завантаження
processor.load_all_files()
grades = processor.merge_data()

# Розрахунок середнього балу по студентах
student_avg = processor.group_and_aggregate(
    grades,
    group_by='ПІБ студента',
    agg_funcs={
        'Оцінка': 'mean',
        'Предмет': 'count'  # Кількість предметів
    }
)
student_avg.columns = ['ПІБ студента', 'Середній бал', 'Кількість предметів']
student_avg = student_avg.sort_values('Середній бал', ascending=False)

# Відмінники (середній бал >= 90)
excellent = student_avg[student_avg['Середній бал'] >= 90]

# Студенти з низькою успішністю (< 60)
at_risk = student_avg[student_avg['Середній бал'] < 60]

# Статистика по предметах
subject_stats = processor.group_and_aggregate(
    grades,
    group_by='Предмет',
    agg_funcs={
        'Оцінка': ['mean', 'min', 'max', 'count']
    }
)

# Список неуспішних оцінок (< 60)
failing = processor.filter_data(grades, {
    'Оцінка': {'max': 59}
})

# Звіт
processor.create_styled_report(
    "academic_performance_report.xlsx",
    **{
        "Всі оцінки": grades,
        "Рейтинг студентів": student_avg,
        "Відмінники": excellent,
        "Потребують уваги": at_risk,
        "Статистика предметів": subject_stats,
        "Неуспішні оцінки": failing
    }
)

print(f"🎓 Відмінників: {len(excellent)}")
print(f"⚠️ Студентів з низькою успішністю: {len(at_risk)}")
```

---

### Сценарій 5: Обробка опитувань / анкет

**Ситуація:** Зібрано анкети від клієнтів. Потрібно проаналізувати відповіді.

**Код:**

```python
from excel_processor import ExcelProcessor
import pandas as pd

processor = ExcelProcessor(
    input_folder="surveys",
    output_folder="survey_analysis"
)

# Завантаження
processor.load_all_files()
surveys = processor.merge_data()

# Підрахунок відповідей
def analyze_column(df, col_name):
    """Підраховує відповіді для колонки"""
    counts = df[col_name].value_counts().reset_index()
    counts.columns = [col_name, 'Кількість']
    counts['Відсоток'] = (counts['Кількість'] / len(df) * 100).round(2)
    return counts

# Аналізуємо кожне питання
results = {}
for col in surveys.columns:
    if col not in ['ID', 'Дата', 'Email']:  # Пропускаємо службові колонки
        results[f"Питання: {col}"] = analyze_column(surveys, col)

# Фільтр: незадоволені клієнти (оцінка < 3)
if 'Загальна оцінка' in surveys.columns:
    unsatisfied = processor.filter_data(surveys, {
        'Загальна оцінка': {'max': 2}
    })
else:
    unsatisfied = pd.DataFrame()

# Демографія (якщо є)
if 'Вік' in surveys.columns:
    age_groups = processor.group_and_aggregate(
        surveys,
        group_by='Віковa група',
        agg_funcs={'ID': 'count'}
    )
else:
    age_groups = pd.DataFrame()

# Створення звіту
processor.create_styled_report(
    "survey_results.xlsx",
    **{
        "Всі відповіді": surveys,
        "Незадоволені": unsatisfied,
        **results
    }
)

print(f"📊 Всього відповідей: {len(surveys)}")
if not unsatisfied.empty:
    print(f"😞 Незадоволених клієнтів: {len(unsatisfied)}")
```

---

## Advanced Tips & Tricks

### 1. Робота з датами

```python
import pandas as pd

# Парсинг дат при читанні
df = pd.read_excel('file.xlsx', parse_dates=['Дата замовлення'])

# Додавання колонок з датами
df['Рік'] = df['Дата'].dt.year
df['Місяць'] = df['Дата'].dt.month
df['День тижня'] = df['Дата'].dt.day_name()
df['Квартал'] = df['Дата'].dt.quarter

# Фільтрація по датах
from datetime import datetime
start_date = datetime(2024, 1, 1)
end_date = datetime(2024, 3, 31)
q1_data = df[(df['Дата'] >= start_date) & (df['Дата'] <= end_date)]
```

### 2. Множинні умови фільтрації

```python
# AND умова
filtered = df[
    (df['Ціна'] > 100) & 
    (df['Кількість'] > 10) & 
    (df['Категорія'] == 'Електроніка')
]

# OR умова
filtered = df[
    (df['Статус'] == 'Терміново') | 
    (df['Пріоритет'] == 'Високий')
]

# NOT умова
filtered = df[~df['Статус'].isin(['Скасовано', 'Відхилено'])]
```

### 3. Створення обчислюваних колонок

```python
# Прості розрахунки
df['Загальна сума'] = df['Ціна'] * df['Кількість']
df['Знижка %'] = (df['Ціна стара'] - df['Ціна нова']) / df['Ціна стара'] * 100

# Умовні значення
df['Категорія ціни'] = df['Ціна'].apply(
    lambda x: 'Дешево' if x < 100 else 'Середня ціна' if x < 500 else 'Дорого'
)

# Використання np.where
import numpy as np
df['Статус запасу'] = np.where(
    df['Кількість'] < 10, 
    'Низький запас', 
    'Норма'
)
```

### 4. Pivot Tables

```python
# Зведена таблиця
pivot = pd.pivot_table(
    df,
    values='Сума',
    index='Категорія',
    columns='Місяць',
    aggfunc='sum',
    fill_value=0
)
```

### 5. Робота з дублікатами

```python
# Знайти дублікати
duplicates = df[df.duplicated(subset=['ID'], keep=False)]

# Видалити дублікати
df_unique = df.drop_duplicates(subset=['ID'], keep='first')

# Порахувати дублікати
duplicate_count = df.duplicated(subset=['ID']).sum()
```

### 6. Експорт в різні формати

```python
# CSV
df.to_csv('output.csv', index=False, encoding='utf-8-sig')

# Excel з різними листами
with pd.ExcelWriter('output.xlsx', engine='openpyxl') as writer:
    df1.to_excel(writer, sheet_name='Data', index=False)
    df2.to_excel(writer, sheet_name='Summary', index=False)

# HTML
df.to_html('output.html', index=False)

# JSON
df.to_json('output.json', orient='records', force_ascii=False)
```

---

## Troubleshooting

### Проблема: "File not found"

**Рішення:**
```python
from pathlib import Path

# Перевірте чи існує файл
file_path = Path("input_data/file.xlsx")
if file_path.exists():
    print("Файл знайдено")
else:
    print(f"Файл не знайдено: {file_path.absolute()}")
```

### Проблема: Кирилиця не відображається

**Рішення:**
```python
# При читанні CSV
df = pd.read_csv('file.csv', encoding='utf-8')

# При записі CSV
df.to_csv('output.csv', encoding='utf-8-sig', index=False)
```

### Проблема: Дати читаються як текст

**Рішення:**
```python
# Вказати при читанні
df = pd.read_excel('file.xlsx', parse_dates=['Дата'])

# Або конвертувати після
df['Дата'] = pd.to_datetime(df['Дата'])
```

### Проблема: Memory Error на великих файлах

**Рішення:**
```python
# Chunking
chunks = []
for chunk in pd.read_excel('large.xlsx', chunksize=10000):
    # Обробка chunk
    processed = process_chunk(chunk)
    chunks.append(processed)

result = pd.concat(chunks, ignore_index=True)
```

---

## Корисні функції pandas

```python
# Інформація про DataFrame
df.info()          # Типи даних, пам'ять
df.describe()      # Статистика
df.head(10)        # Перші рядки
df.tail(10)        # Останні рядки
df.shape           # (рядки, колонки)
df.columns         # Список колонок
df.dtypes          # Типи колонок

# Перевірка на пропущені значення
df.isnull().sum()
df.dropna()        # Видалити рядки з NA
df.fillna(0)       # Заповнити NA

# Сортування
df.sort_values('Колонка', ascending=False)
df.sort_values(['Колонка1', 'Колонка2'])

# Унікальні значення
df['Колонка'].unique()
df['Колонка'].nunique()
df['Колонка'].value_counts()
```

---

**Більше прикладів дивіться у файлі `examples.py`!**
