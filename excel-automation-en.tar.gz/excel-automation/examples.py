"""
Приклади використання Excel Processor
"""

from excel_processor import ExcelProcessor
import pandas as pd
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def example_1_basic_merge():
    """Приклад 1: Базове об'єднання файлів"""
    print("\n=== Приклад 1: Базове об'єднання ===")
    
    processor = ExcelProcessor()
    processor.load_all_files()
    merged = processor.merge_data()
    
    print(f"Об'єднано рядків: {len(merged)}")
    print(f"Колонки: {list(merged.columns)}")


def example_2_statistics():
    """Приклад 2: Розрахунок статистики"""
    print("\n=== Приклад 2: Статистика ===")
    
    processor = ExcelProcessor()
    processor.load_all_files()
    merged = processor.merge_data()
    
    stats = processor.calculate_statistics(merged)
    print("\nСтатистика:")
    print(stats)


def example_3_filtering():
    """Приклад 3: Фільтрація даних"""
    print("\n=== Приклад 3: Фільтрація ===")
    
    processor = ExcelProcessor()
    processor.load_all_files()
    merged = processor.merge_data()
    
    # Фільтр: Ціна > 200 AND Категорія = 'Електроніка'
    filtered = processor.filter_data(merged, {
        'Ціна': {'min': 200},
        'Категорія': 'Електроніка'
    })
    
    print(f"Результат фільтрації: {len(filtered)} рядків")


def example_4_grouping():
    """Приклад 4: Групування та агрегація"""
    print("\n=== Приклад 4: Групування ===")
    
    processor = ExcelProcessor()
    processor.load_all_files()
    merged = processor.merge_data()
    
    # Групуємо по категоріях і рахуємо статистику
    grouped = processor.group_and_aggregate(
        merged,
        group_by='Категорія',
        agg_funcs={
            'Ціна': 'mean',
            'Кількість': 'sum'
        }
    )
    
    print("\nСтатистика по категоріях:")
    print(grouped)


def example_5_complex_report():
    """Приклад 5: Комплексний звіт"""
    print("\n=== Приклад 5: Комплексний звіт ===")
    
    processor = ExcelProcessor()
    processor.load_all_files()
    merged = processor.merge_data()
    
    # Розрахунок загальної вартості
    if 'Ціна' in merged.columns and 'Кількість' in merged.columns:
        merged['Загальна вартість'] = merged['Ціна'] * merged['Кількість']
    
    # Статистика
    stats = processor.calculate_statistics(merged)
    
    # Топ товарів по вартості
    if 'Загальна вартість' in merged.columns:
        top_products = merged.nlargest(10, 'Загальна вартість')[
            ['Продукт', 'Категорія', 'Ціна', 'Кількість', 'Загальна вартість']
        ]
    else:
        top_products = merged.head(10)
    
    # Статистика по категоріях
    if 'Категорія' in merged.columns:
        category_stats = processor.group_and_aggregate(
            merged,
            group_by='Категорія',
            agg_funcs={
                'Ціна': 'mean',
                'Кількість': 'sum'
            }
        )
    else:
        category_stats = pd.DataFrame()
    
    # Створюємо звіт з декількома листами
    report_path = processor.create_styled_report(
        "complex_report.xlsx",
        **{
            "Всі дані": merged,
            "Статистика": stats,
            "Топ 10 товарів": top_products,
            "По категоріях": category_stats
        }
    )
    
    print(f"✅ Комплексний звіт створено: {report_path}")


def example_6_custom_filters():
    """Приклад 6: Складні фільтри"""
    print("\n=== Приклад 6: Складні фільтри ===")
    
    processor = ExcelProcessor()
    processor.load_all_files()
    merged = processor.merge_data()
    
    # Фільтр: Ціна від 100 до 300, Кількість > 50
    filtered = processor.filter_data(merged, {
        'Ціна': {'min': 100, 'max': 300},
        'Кількість': {'min': 50}
    })
    
    print(f"Результат складної фільтрації: {len(filtered)} рядків")
    
    # Додатковий фільтр по тексту
    if 'Продукт' in filtered.columns:
        text_filtered = processor.filter_data(filtered, {
            'Продукт': {'contains': 'Товар 1'}
        })
        print(f"З текстовим фільтром: {len(text_filtered)} рядків")


def run_all_examples():
    """Запускає всі приклади"""
    examples = [
        example_1_basic_merge,
        example_2_statistics,
        example_3_filtering,
        example_4_grouping,
        example_5_complex_report,
        example_6_custom_filters
    ]
    
    for example in examples:
        try:
            example()
        except Exception as e:
            logger.error(f"Помилка в {example.__name__}: {e}")
        print("\n" + "="*50)


if __name__ == "__main__":
    # Спочатку створюємо приклад даних
    from excel_processor import create_sample_data
    create_sample_data()
    
    # Запускаємо приклади
    run_all_examples()
