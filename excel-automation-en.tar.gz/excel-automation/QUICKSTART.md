# 🚀 Швидкий старт - Excel Automation

## За 5 хвилин до першого звіту!

### Крок 1: Встановлення (1 хв)

```bash
# Встановіть залежності
pip install -r requirements.txt
```

### Крок 2: Створення тестових даних (30 сек)

```bash
python excel_processor.py --create-sample
```

Це створить:
- Папку `input_data/` з двома Excel файлами
- Кожен файл містить 50 записів про продукти

### Крок 3: Запуск (30 сек)

```bash
python excel_processor.py
```

Результат:
- Папка `output/` з готовим звітом
- Звіт містить 3 листи: "Всі дані", "Статистика", "Відфільтровані дані"

### Крок 4: Перегляд результату

Відкрийте файл у папці `output/`:
```
output/report_YYYYMMDD_HHMMSS.xlsx
```

## 🎯 Що далі?

### Використати свої дані

1. Покладіть ваші Excel файли в папку `input_data/`
2. Запустіть: `python excel_processor.py`
3. Отримайте звіт у папці `output/`

### Запустити приклади

```bash
python examples.py
```

Побачите 6 різних прикладів обробки даних.

### Свої налаштування

```python
from excel_processor import ExcelProcessor

processor = ExcelProcessor(
    input_folder="my_data",
    output_folder="my_reports"
)

processor.load_all_files()
data = processor.merge_data()
stats = processor.calculate_statistics(data)
processor.create_summary_report(data, stats)
```

## 💡 Корисні команди

```bash
# Допомога
python excel_processor.py --help

# Вказати папки
python excel_processor.py --input my_folder --output results

# Створити нові тестові дані
python excel_processor.py --create-sample
```

## ❓ Проблеми?

**Помилка імпорту:**
```bash
pip install pandas openpyxl numpy
```

**Немає даних:**
```bash
python excel_processor.py --create-sample
```

**Детальна документація:**
Читайте [README.md](README.md)

---

**Готово!** Тепер у вас є працюючий інструмент автоматизації Excel 🎉
